import React, { createContext, useContext, useState, useEffect } from 'react';
import { User, Complaint, Issue, SmsOutboxItem } from '../types.js';

interface AppContextType {
  currentUser: User;
  users: User[];
  setCurrentUser: (user: User) => void;
  switchRole: (role: 'citizen_a' | 'citizen_b' | 'officer' | 'admin') => void;
  isOffline: boolean;
  setIsOffline: (val: boolean) => void;
  offlineQueue: any[];
  addOfflineReport: (report: any) => void;
  syncOfflineQueue: () => Promise<number>;
  activeTab: string;
  setActiveTab: (tab: string) => void;
  selectedIssueId: number | null;
  setSelectedIssueId: (id: number | null) => void;
  recentSms: SmsOutboxItem | null;
  dismissRecentSms: () => void;
  demoModalOpen: boolean;
  setDemoModalOpen: (open: boolean) => void;
  refreshKey: number;
  triggerRefresh: () => void;
}

const defaultUsers: User[] = [
  {
    id: 1,
    role: 'citizen',
    displayName: 'Priya Narayanan (Citizen A)',
    phoneNumber: '+91 98401 23456',
    createdAt: '2026-08-20T10:00:00Z',
  },
  {
    id: 2,
    role: 'citizen',
    displayName: 'Karthik Raja (Citizen B)',
    phoneNumber: '+91 98402 34567',
    createdAt: '2026-08-20T10:30:00Z',
  },
  {
    id: 3,
    role: 'officer',
    displayName: 'Officer Ramesh Kumar',
    phoneNumber: '+91 94440 11223',
    departmentId: 1,
    jurisdictionZoneId: 1,
    createdAt: '2026-08-01T09:00:00Z',
  },
  {
    id: 4,
    role: 'admin',
    displayName: 'Dr. Sundar Murthy (Municipal Admin)',
    phoneNumber: '+91 94440 99887',
    createdAt: '2026-08-01T08:00:00Z',
  },
];

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [users, setUsers] = useState<User[]>(defaultUsers);
  const [currentUser, setCurrentUser] = useState<User>(defaultUsers[0]); // Default to Priya (Citizen A)
  const [isOffline, setIsOffline] = useState<boolean>(false);
  const [offlineQueue, setOfflineQueue] = useState<any[]>(() => {
    try {
      const saved = localStorage.getItem('citizen_offline_queue');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });
  const [activeTab, setActiveTab] = useState<string>('citizen_home');
  const [selectedIssueId, setSelectedIssueId] = useState<number | null>(null);
  const [recentSms, setRecentSms] = useState<SmsOutboxItem | null>(null);
  const [demoModalOpen, setDemoModalOpen] = useState<boolean>(false);
  const [refreshKey, setRefreshKey] = useState<number>(0);

  const triggerRefresh = () => setRefreshKey((k) => k + 1);

  // Fetch users from backend
  useEffect(() => {
    fetch('/api/v1/users')
      .then((res) => res.json())
      .then((data) => {
        if (data?.data && Array.isArray(data.data)) {
          setUsers(data.data);
          const found = data.data.find((u: User) => u.id === currentUser.id);
          if (found) setCurrentUser(found);
        }
      })
      .catch(() => {});
  }, [refreshKey]);

  // Poll for SMS notifications for demo delight
  useEffect(() => {
    const checkSms = () => {
      fetch('/api/v1/admin/sms-outbox')
        .then((res) => res.json())
        .then((data) => {
          if (data?.data && data.data.length > 0) {
            const latest = data.data[0];
            // If latest matches user phone or admin, surface
            if (
              latest.toPhoneNumber === currentUser.phoneNumber ||
              currentUser.role === 'admin'
            ) {
              setRecentSms((prev) => (prev?.id === latest.id ? prev : latest));
            }
          }
        })
        .catch(() => {});
    };

    const interval = setInterval(checkSms, 3000);
    return () => clearInterval(interval);
  }, [currentUser, refreshKey]);

  const switchRole = (roleType: 'citizen_a' | 'citizen_b' | 'officer' | 'admin') => {
    let targetUser: User;
    if (roleType === 'citizen_a') {
      targetUser = users.find((u) => u.id === 1) || users[0];
      setActiveTab('citizen_home');
    } else if (roleType === 'citizen_b') {
      targetUser = users.find((u) => u.id === 2) || users[1] || users[0];
      setActiveTab('citizen_home');
    } else if (roleType === 'officer') {
      targetUser = users.find((u) => u.id === 3 && u.role === 'officer') || users[2];
      setActiveTab('officer_dashboard');
    } else {
      targetUser = users.find((u) => u.id === 4 && u.role === 'admin') || users[3];
      setActiveTab('admin_dashboard');
    }
    setCurrentUser(targetUser);
  };

  const addOfflineReport = (report: any) => {
    const updated = [...offlineQueue, { ...report, queuedAt: new Date().toISOString() }];
    setOfflineQueue(updated);
    try {
      localStorage.setItem('citizen_offline_queue', JSON.stringify(updated));
    } catch {}
  };

  const syncOfflineQueue = async (): Promise<number> => {
    if (offlineQueue.length === 0) return 0;
    try {
      const res = await fetch('/api/v1/complaints/sync-batch', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-demo-user-id': String(currentUser.id),
        },
        body: JSON.stringify({ reports: offlineQueue }),
      });
      const data = await res.json();
      const count = offlineQueue.length;
      setOfflineQueue([]);
      try {
        localStorage.removeItem('citizen_offline_queue');
      } catch {}
      triggerRefresh();
      return count;
    } catch (e) {
      console.error('Failed to sync offline queue:', e);
      return 0;
    }
  };

  return (
    <AppContext.Provider
      value={{
        currentUser,
        users,
        setCurrentUser,
        switchRole,
        isOffline,
        setIsOffline,
        offlineQueue,
        addOfflineReport,
        syncOfflineQueue,
        activeTab,
        setActiveTab,
        selectedIssueId,
        setSelectedIssueId,
        recentSms,
        dismissRecentSms: () => setRecentSms(null),
        demoModalOpen,
        setDemoModalOpen,
        refreshKey,
        triggerRefresh,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) throw new Error('useApp must be used within an AppProvider');
  return context;
};
