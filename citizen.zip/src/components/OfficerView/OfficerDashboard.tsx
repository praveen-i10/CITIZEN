import React, { useState, useEffect, useRef } from 'react';
import { useApp } from '../../context/AppContext.js';
import { Issue, PriorityBreakdown } from '../../types.js';
import { ResolutionCaptureModal } from './ResolutionCaptureModal.js';
import {
  HardHat,
  AlertTriangle,
  Clock,
  MapPin,
  CheckCircle2,
  ChevronRight,
  TrendingUp,
  Layers,
  Sparkles,
  Camera,
  Play,
  ShieldCheck,
  Building2,
  Users,
  Info,
  X,
} from 'lucide-react';
import L from 'leaflet';

export const OfficerDashboard: React.FC = () => {
  const { currentUser, refreshKey, triggerRefresh } = useApp();

  const [officerData, setOfficerData] = useState<any | null>(null);
  const [issues, setIssues] = useState<any[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [filterCategory, setFilterCategory] = useState<string>('all');
  const [activeTab, setActiveTab] = useState<'queue' | 'map'>('queue');

  // Selected issue for Priority Factor Breakdown Modal
  const [breakdownIssue, setBreakdownIssue] = useState<any | null>(null);

  // Selected issue for Resolution Capture Modal
  const [resolvingIssue, setResolvingIssue] = useState<any | null>(null);

  // Map refs
  const mapContainerRef = useRef<HTMLDivElement>(null);
  const mapInstanceRef = useRef<L.Map | null>(null);
  const markersGroupRef = useRef<L.LayerGroup | null>(null);

  useEffect(() => {
    fetchOfficerDashboard();
  }, [currentUser, refreshKey]);

  const fetchOfficerDashboard = async () => {
    try {
      setLoading(true);
      const res = await fetch('/api/v1/officer/dashboard', {
        headers: { 'x-demo-user-id': String(currentUser.id) },
      });
      const data = await res.json();
      if (data?.data) {
        setOfficerData(data.data.officer);
        setIssues(data.data.issues || []);
      }
    } catch (e) {
      console.warn('Failed to load officer dashboard:', e);
    } finally {
      setLoading(false);
    }
  };

  const handleAcknowledge = async (issueId: number) => {
    try {
      await fetch(`/api/v1/officer/issues/${issueId}/acknowledge`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'x-demo-user-id': String(currentUser.id) },
      });
      triggerRefresh();
    } catch (err: any) {
      alert('Failed to acknowledge: ' + err.message);
    }
  };

  const handleStartWork = async (issueId: number) => {
    try {
      await fetch(`/api/v1/officer/issues/${issueId}/start-work`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'x-demo-user-id': String(currentUser.id) },
      });
      triggerRefresh();
    } catch (err: any) {
      alert('Failed to start work: ' + err.message);
    }
  };

  // Setup Leaflet map when switching to map tab
  useEffect(() => {
    if (activeTab !== 'map' || !mapContainerRef.current) return;

    if (!mapInstanceRef.current) {
      const map = L.map(mapContainerRef.current, {
        center: [13.0015, 80.2575], // Adyar
        zoom: 13,
      });

      L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '&copy; OpenStreetMap contributors',
      }).addTo(map);

      // Adyar polygon
      const adyarBoundary = [
        [13.010, 80.220],
        [13.010, 80.275],
        [12.980, 80.275],
        [12.980, 80.220],
      ];
      L.polygon(adyarBoundary as L.LatLngExpression[], {
        color: '#d97706',
        weight: 2,
        fillColor: '#f59e0b',
        fillOpacity: 0.08,
      }).addTo(map);

      markersGroupRef.current = L.layerGroup().addTo(map);
      mapInstanceRef.current = map;
    }

    if (markersGroupRef.current && mapInstanceRef.current) {
      markersGroupRef.current.clearLayers();

      issues.forEach((issue) => {
        const isHigh = issue.priorityScore >= 70;
        const color = isHigh ? '#dc2626' : '#d97706';

        const customIcon = L.divIcon({
          className: 'custom-officer-pin',
          html: `<div style="
            background-color: ${color};
            color: white;
            padding: 2px 6px;
            border-radius: 12px;
            font-weight: 800;
            font-size: 11px;
            border: 2px solid white;
            box-shadow: 0 2px 8px rgba(0,0,0,0.3);
            white-space: nowrap;
          ">#${issue.id} · Priority ${issue.priorityScore.toFixed(0)}</div>`,
          iconSize: [80, 24],
          iconAnchor: [40, 12],
        });

        const marker = L.marker([issue.representativeLat, issue.representativeLng], { icon: customIcon });
        marker.bindPopup(`
          <div style="font-family: sans-serif; font-size: 12px;">
            <strong>Issue #${issue.id} (${issue.category})</strong><br/>
            Priority Score: <strong>${issue.priorityScore.toFixed(1)}</strong><br/>
            Status: ${issue.status}<br/>
            Complaints: ${issue.complaintCount}
          </div>
        `);
        markersGroupRef.current?.addLayer(marker);
      });
    }
  }, [activeTab, issues]);

  const filteredIssues = issues.filter((i) => {
    if (filterCategory === 'all') return true;
    if (filterCategory === 'high_priority') return i.priorityScore >= 70;
    if (filterCategory === 'ongoing') return i.status === 'ongoing';
    return i.category === filterCategory;
  });

  return (
    <div className="max-w-6xl mx-auto px-4 py-8 space-y-6">
      {/* Officer Header Card */}
      <div className="bg-slate-900 text-white rounded-2xl p-6 shadow-md border border-slate-800 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-xl bg-amber-500/20 border border-amber-400/30 flex items-center justify-center text-amber-400 font-bold">
            <HardHat className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-lg font-bold">Officer रमेश (Ramesh Kumar)</h2>
              <span className="bg-amber-400/20 text-amber-300 text-[10px] font-bold px-2 py-0.5 rounded-full border border-amber-400/30 uppercase">
                Zone 13 Adyar
              </span>
            </div>
            <p className="text-xs text-slate-400">
              Department: Roads & Infrastructure · Operating Queue (Sorted by Priority Score)
            </p>
          </div>
        </div>

        <div className="flex items-center gap-4 text-xs font-mono">
          <div className="bg-slate-800 px-3 py-2 rounded-xl border border-slate-700">
            <span className="text-slate-400 block text-[10px]">TOTAL OPEN</span>
            <span className="text-lg font-extrabold text-white">{issues.length}</span>
          </div>
          <div className="bg-slate-800 px-3 py-2 rounded-xl border border-slate-700">
            <span className="text-slate-400 block text-[10px]">HIGH PRIORITY</span>
            <span className="text-lg font-extrabold text-rose-400">
              {issues.filter((i) => i.priorityScore >= 70).length}
            </span>
          </div>
        </div>
      </div>

      {/* Tabs & Filters */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div className="flex items-center bg-slate-100 p-1 rounded-xl border border-slate-200 text-xs font-bold w-fit">
          <button
            onClick={() => setActiveTab('queue')}
            className={`px-3.5 py-1.5 rounded-lg transition ${
              activeTab === 'queue' ? 'bg-white text-amber-700 shadow-xs' : 'text-slate-600'
            }`}
          >
            Priority Queue View ({issues.length})
          </button>
          <button
            onClick={() => setActiveTab('map')}
            className={`px-3.5 py-1.5 rounded-lg transition ${
              activeTab === 'map' ? 'bg-white text-amber-700 shadow-xs' : 'text-slate-600'
            }`}
          >
            Jurisdiction Map & Pins
          </button>
        </div>

        {/* Filter Pills */}
        <div className="flex items-center gap-2 overflow-x-auto text-xs font-semibold">
          <button
            onClick={() => setFilterCategory('all')}
            className={`px-3 py-1.5 rounded-lg border transition ${
              filterCategory === 'all'
                ? 'bg-slate-900 text-white border-slate-900'
                : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-50'
            }`}
          >
            All Issues
          </button>
          <button
            onClick={() => setFilterCategory('high_priority')}
            className={`px-3 py-1.5 rounded-lg border transition ${
              filterCategory === 'high_priority'
                ? 'bg-rose-600 text-white border-rose-600'
                : 'bg-white text-rose-700 border-rose-200 hover:bg-rose-50'
            }`}
          >
            High Priority (≥70)
          </button>
          <button
            onClick={() => setFilterCategory('ongoing')}
            className={`px-3 py-1.5 rounded-lg border transition ${
              filterCategory === 'ongoing'
                ? 'bg-amber-600 text-white border-amber-600'
                : 'bg-white text-amber-700 border-amber-200 hover:bg-amber-50'
            }`}
          >
            Work in Progress
          </button>
        </div>
      </div>

      {/* Main Content Area */}
      {activeTab === 'queue' ? (
        <div className="space-y-4">
          {loading ? (
            <div className="p-12 text-center text-xs text-slate-500">Loading work queue...</div>
          ) : filteredIssues.length === 0 ? (
            <div className="bg-white rounded-2xl border border-slate-200 p-12 text-center text-xs text-slate-500">
              No issues currently match this filter.
            </div>
          ) : (
            filteredIssues.map((issue, rank) => {
              const isHigh = issue.priorityScore >= 70;
              return (
                <div
                  key={issue.id}
                  className={`bg-white rounded-2xl border transition p-5 shadow-xs hover:shadow-md space-y-4 ${
                    isHigh ? 'border-rose-200 bg-gradient-to-r from-white to-rose-50/20' : 'border-slate-200'
                  }`}
                >
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                    <div className="flex items-start sm:items-center gap-3">
                      {/* Priority Rank Badge */}
                      <div
                        className={`w-10 h-10 rounded-xl flex items-center justify-center font-extrabold text-sm shrink-0 ${
                          isHigh ? 'bg-rose-600 text-white shadow-xs' : 'bg-slate-100 text-slate-700'
                        }`}
                        title={`Queue Rank #${rank + 1}`}
                      >
                        #{rank + 1}
                      </div>

                      {issue.firstPhoto && (
                        <img
                          src={issue.firstPhoto}
                          alt={issue.category}
                          className="w-16 h-16 rounded-xl object-cover border border-slate-200 shrink-0"
                        />
                      )}

                      <div>
                        <div className="flex items-center gap-2">
                          <span className="font-mono text-xs font-bold text-blue-600">
                            ISSUE #{issue.id}
                          </span>
                          <span
                            className={`px-2.5 py-0.5 rounded-full text-[11px] font-bold uppercase ${
                              issue.status === 'submitted'
                                ? 'bg-blue-100 text-blue-800'
                                : issue.status === 'acknowledged'
                                ? 'bg-purple-100 text-purple-800'
                                : issue.status === 'ongoing'
                                ? 'bg-amber-100 text-amber-800'
                                : issue.status === 'needs_verification'
                                ? 'bg-rose-100 text-rose-800'
                                : 'bg-emerald-100 text-emerald-800'
                            }`}
                          >
                            {issue.status}
                          </span>
                          <span className="bg-emerald-50 text-emerald-800 border border-emerald-200 px-2 py-0.5 rounded-md text-[10px] font-bold">
                            Confidence: {issue.evidenceConfidenceBand?.toUpperCase()}
                          </span>
                        </div>

                        <h3 className="text-base font-extrabold text-slate-900 capitalize mt-1">
                          {issue.category.replace('_', ' ')}
                        </h3>

                        <div className="flex flex-wrap items-center gap-3 text-xs text-slate-500 mt-1">
                          <span className="flex items-center gap-1 font-medium text-slate-700">
                            <Users className="w-3.5 h-3.5 text-blue-600" />
                            <strong>{issue.complaintCount}</strong> report(s) ·{' '}
                            <strong>{issue.independentReportersCount}</strong> independent reporter(s)
                          </span>
                          <span className="flex items-center gap-1">
                            <MapPin className="w-3.5 h-3.5" />
                            {issue.wardLabel || 'Ward 175 Adyar'}
                          </span>
                        </div>
                      </div>
                    </div>

                    {/* Priority Score Display & Breakdown Trigger */}
                    <div className="flex sm:flex-col items-end justify-between sm:justify-center gap-2">
                      <div className="text-right">
                        <span className="text-[10px] font-bold text-slate-400 block uppercase">
                          8-Factor Risk Score
                        </span>
                        <span
                          className={`text-2xl font-black ${
                            isHigh ? 'text-rose-600' : 'text-slate-800'
                          }`}
                        >
                          {issue.priorityScore.toFixed(1)}
                          <span className="text-xs text-slate-400 font-normal"> / 100</span>
                        </span>
                      </div>

                      <button
                        onClick={() => setBreakdownIssue(issue)}
                        className="text-xs font-bold text-blue-600 hover:text-blue-700 inline-flex items-center gap-1 bg-blue-50 px-2.5 py-1 rounded-lg border border-blue-200 transition"
                      >
                        <TrendingUp className="w-3.5 h-3.5" />
                        <span>Inspect Breakdown</span>
                      </button>
                    </div>
                  </div>

                  {/* Officer Action Workflow Bar (F-14) */}
                  <div className="pt-3 border-t border-slate-100 flex flex-wrap items-center justify-between gap-3">
                    <div className="text-xs text-slate-500">
                      {issue.status === 'submitted' && (
                        <span>Next Step: Acknowledge report and inspect location.</span>
                      )}
                      {issue.status === 'acknowledged' && (
                        <span>Next Step: Dispatch field crew and start road repairs.</span>
                      )}
                      {issue.status === 'ongoing' && (
                        <span className="text-amber-700 font-semibold">
                          Repairs in progress. Capture fresh photo evidence to resolve.
                        </span>
                      )}
                    </div>

                    <div className="flex items-center gap-2">
                      {issue.status === 'submitted' && (
                        <button
                          onClick={() => handleAcknowledge(issue.id)}
                          className="bg-purple-600 hover:bg-purple-500 text-white text-xs font-bold px-4 py-2 rounded-xl shadow-xs transition"
                        >
                          Acknowledge Issue
                        </button>
                      )}

                      {issue.status === 'acknowledged' && (
                        <button
                          onClick={() => handleStartWork(issue.id)}
                          className="bg-amber-600 hover:bg-amber-500 text-white text-xs font-bold px-4 py-2 rounded-xl shadow-xs transition"
                        >
                          Start Work / Dispatch Crew
                        </button>
                      )}

                      {(issue.status === 'ongoing' || issue.status === 'acknowledged') && (
                        <button
                          onClick={() => setResolvingIssue(issue)}
                          className="bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold px-4 py-2 rounded-xl shadow-xs transition flex items-center gap-1.5"
                        >
                          <Camera className="w-4 h-4" />
                          <span>Mark Resolved (Capture Proof)</span>
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </div>
      ) : (
        /* Leaflet Map Tab */
        <div className="bg-white rounded-2xl border border-slate-200 p-2 shadow-sm overflow-hidden h-[540px]">
          <div ref={mapContainerRef} className="w-full h-full rounded-xl" />
        </div>
      )}

      {/* 8-Factor Priority Score Breakdown Modal (DEC-17, F-09) */}
      {breakdownIssue && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-xl w-full max-h-[90vh] overflow-y-auto p-6 shadow-2xl space-y-5">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div>
                <span className="text-xs font-bold font-mono text-blue-600">
                  ISSUE #{breakdownIssue.id} · MATHEMATICAL BREAKDOWN
                </span>
                <h3 className="text-lg font-extrabold text-slate-900">
                  8-Factor Priority Score: {breakdownIssue.priorityScore.toFixed(1)} / 100
                </h3>
              </div>
              <button
                onClick={() => setBreakdownIssue(null)}
                className="text-slate-400 hover:text-slate-700 p-1.5 rounded-lg hover:bg-slate-100"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <p className="text-xs text-slate-600 leading-relaxed">
              Every civic issue in CITIZEN is transparently scored using 8 weighted factors to prevent
              bias and ensure critical road hazards with high public exposure and multiple independent
              reporters are addressed first.
            </p>

            {/* Breakdown Bars */}
            <div className="space-y-3 bg-slate-50 p-4 rounded-xl border border-slate-200 text-xs">
              {/* 1. Severity */}
              <div>
                <div className="flex justify-between font-bold text-slate-800 mb-1">
                  <span>1. Physical Severity (Weight: 20%)</span>
                  <span>{breakdownIssue.priorityBreakdown?.severity || 85} / 100</span>
                </div>
                <div className="w-full h-2 bg-slate-200 rounded-full overflow-hidden">
                  <div
                    className="bg-rose-500 h-full rounded-full"
                    style={{ width: `${breakdownIssue.priorityBreakdown?.severity || 85}%` }}
                  />
                </div>
              </div>

              {/* 2. Public Exposure */}
              <div>
                <div className="flex justify-between font-bold text-slate-800 mb-1">
                  <span>2. Public Exposure / Traffic Volume (Weight: 15%)</span>
                  <span>{breakdownIssue.priorityBreakdown?.publicExposure || 85} / 100</span>
                </div>
                <div className="w-full h-2 bg-slate-200 rounded-full overflow-hidden">
                  <div
                    className="bg-amber-500 h-full rounded-full"
                    style={{ width: `${breakdownIssue.priorityBreakdown?.publicExposure || 85}%` }}
                  />
                </div>
              </div>

              {/* 3. Vulnerable Population */}
              <div>
                <div className="flex justify-between font-bold text-slate-800 mb-1">
                  <span>3. Vulnerable Population Impact (Pedestrians/School) (Weight: 15%)</span>
                  <span>{breakdownIssue.priorityBreakdown?.vulnerablePopulation || 80} / 100</span>
                </div>
                <div className="w-full h-2 bg-slate-200 rounded-full overflow-hidden">
                  <div
                    className="bg-purple-500 h-full rounded-full"
                    style={{ width: `${breakdownIssue.priorityBreakdown?.vulnerablePopulation || 80}%` }}
                  />
                </div>
              </div>

              {/* 4. Critical Infrastructure */}
              <div>
                <div className="flex justify-between font-bold text-slate-800 mb-1">
                  <span>4. Critical Infrastructure (Bus Routes/Hospitals) (Weight: 10%)</span>
                  <span>{breakdownIssue.priorityBreakdown?.criticalInfrastructure || 75} / 100</span>
                </div>
                <div className="w-full h-2 bg-slate-200 rounded-full overflow-hidden">
                  <div
                    className="bg-blue-500 h-full rounded-full"
                    style={{ width: `${breakdownIssue.priorityBreakdown?.criticalInfrastructure || 75}%` }}
                  />
                </div>
              </div>

              {/* 5. Duration */}
              <div>
                <div className="flex justify-between font-bold text-slate-800 mb-1">
                  <span>5. Duration / Age Factor (Weight: 10%)</span>
                  <span>{breakdownIssue.priorityBreakdown?.duration || 60} / 100</span>
                </div>
                <div className="w-full h-2 bg-slate-200 rounded-full overflow-hidden">
                  <div
                    className="bg-slate-600 h-full rounded-full"
                    style={{ width: `${breakdownIssue.priorityBreakdown?.duration || 60}%` }}
                  />
                </div>
              </div>

              {/* 6. Community Corroboration */}
              <div>
                <div className="flex justify-between font-bold text-slate-800 mb-1">
                  <span>6. Community Corroboration (Independent Reports) (Weight: 10%)</span>
                  <span className="text-blue-600 font-extrabold">
                    {breakdownIssue.priorityBreakdown?.communityCorroboration || 90} / 100
                  </span>
                </div>
                <div className="w-full h-2 bg-slate-200 rounded-full overflow-hidden">
                  <div
                    className="bg-blue-600 h-full rounded-full"
                    style={{ width: `${breakdownIssue.priorityBreakdown?.communityCorroboration || 90}%` }}
                  />
                </div>
              </div>

              {/* 7. Recurrence */}
              <div>
                <div className="flex justify-between font-bold text-slate-800 mb-1">
                  <span>7. Recurring Defect Factor (Weight: 10%)</span>
                  <span>{breakdownIssue.priorityBreakdown?.recurrence || 70} / 100</span>
                </div>
                <div className="w-full h-2 bg-slate-200 rounded-full overflow-hidden">
                  <div
                    className="bg-indigo-500 h-full rounded-full"
                    style={{ width: `${breakdownIssue.priorityBreakdown?.recurrence || 70}%` }}
                  />
                </div>
              </div>

              {/* 8. Evidence Confidence */}
              <div>
                <div className="flex justify-between font-bold text-slate-800 mb-1">
                  <span>8. Evidence Confidence Score (Weight: 10%)</span>
                  <span className="text-emerald-700 font-extrabold">
                    {breakdownIssue.priorityBreakdown?.evidenceConfidence || 95} / 100
                  </span>
                </div>
                <div className="w-full h-2 bg-slate-200 rounded-full overflow-hidden">
                  <div
                    className="bg-emerald-600 h-full rounded-full"
                    style={{ width: `${breakdownIssue.priorityBreakdown?.evidenceConfidence || 95}%` }}
                  />
                </div>
              </div>
            </div>

            <div className="pt-2 flex justify-end">
              <button
                onClick={() => setBreakdownIssue(null)}
                className="bg-slate-900 text-white font-bold px-5 py-2 rounded-xl text-xs"
              >
                Close Breakdown
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Resolution Capture Modal */}
      {resolvingIssue && (
        <ResolutionCaptureModal
          issue={resolvingIssue}
          onClose={() => setResolvingIssue(null)}
          onSuccess={() => {
            setResolvingIssue(null);
            fetchOfficerDashboard();
          }}
        />
      )}
    </div>
  );
};
