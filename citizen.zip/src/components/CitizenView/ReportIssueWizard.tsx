import React, { useState, useRef, useEffect } from 'react';
import { useApp } from '../../context/AppContext.js';
import { IssueCategory, DuplicateCandidate } from '../../types.js';
import {
  Camera,
  Mic,
  MicOff,
  MapPin,
  Clock,
  Sparkles,
  CheckCircle2,
  AlertTriangle,
  ArrowRight,
  ArrowLeft,
  RotateCcw,
  Volume2,
  ChevronRight,
  Layers,
  Info,
} from 'lucide-react';

const SAMPLE_PHOTOS = [
  {
    id: 'pothole_adyar',
    label: 'Adyar 2nd Ave Pothole (Demo)',
    url: 'https://images.unsplash.com/photo-1515162816999-a0c47dc192f7?auto=format&fit=crop&w=600&q=80',
    lat: 13.0015,
    lng: 80.2575,
    locationName: '2nd Avenue, Adyar (Zone 13)',
  },
  {
    id: 'garbage_bin',
    label: 'Overflowing Waste Bin',
    url: 'https://images.unsplash.com/photo-1530587191325-3db32d826c18?auto=format&fit=crop&w=600&q=80',
    lat: 13.0335,
    lng: 80.2680,
    locationName: 'Luz Church Road, Mylapore',
  },
  {
    id: 'broken_light',
    label: 'Broken LED Streetlight',
    url: 'https://images.unsplash.com/photo-1517457373958-b7bdd4587205?auto=format&fit=crop&w=600&q=80',
    lat: 13.0390,
    lng: 80.2320,
    locationName: 'North Usman Road, T. Nagar',
  },
  {
    id: 'water_leak',
    label: 'Pipeline Water Leak',
    url: 'https://images.unsplash.com/photo-1584467735815-f778f274e296?auto=format&fit=crop&w=600&q=80',
    lat: 13.0825,
    lng: 80.2110,
    locationName: 'Anna Nagar 2nd Avenue',
  },
];

const CATEGORIES: { id: IssueCategory; label: string; icon: string; dept: string }[] = [
  { id: 'pothole', label: 'Pothole & Craters', icon: '🕳️', dept: 'Roads & Infrastructure' },
  { id: 'garbage', label: 'Garbage & Waste', icon: '🗑️', dept: 'Solid Waste Management' },
  { id: 'streetlight', label: 'Streetlight & Electrical', icon: '💡', dept: 'Electrical Works' },
  { id: 'drainage', label: 'Drainage & Sewage Overflow', icon: '🌊', dept: 'Water Supply & Sewerage' },
  { id: 'footpath', label: 'Damaged Footpath / Pavers', icon: '🚶', dept: 'Roads & Infrastructure' },
  { id: 'road_damage', label: 'Road Damage / Resurfacing', icon: '🚧', dept: 'Roads & Infrastructure' },
  { id: 'water_supply', label: 'Drinking Water Pipeline', icon: '🚰', dept: 'Metro Water' },
  { id: 'other', label: 'Other Civic Issue', icon: '📍', dept: 'General Public Works' },
];

interface ReportIssueWizardProps {
  onFinish: () => void;
}

export const ReportIssueWizard: React.FC<ReportIssueWizardProps> = ({ onFinish }) => {
  const { currentUser, isOffline, addOfflineReport, triggerRefresh } = useApp();

  // Wizard Steps: 1: Capture Photo, 2: Description & Voice, 3: AI Category, 4: Duplicate Check, 5: Submitted
  const [step, setStep] = useState<number>(1);

  // Form State
  const [capturedPhotoUrl, setCapturedPhotoUrl] = useState<string>(SAMPLE_PHOTOS[0].url);
  const [gpsCoords, setGpsCoords] = useState<{ lat: number; lng: number }>({
    lat: SAMPLE_PHOTOS[0].lat,
    lng: SAMPLE_PHOTOS[0].lng,
  });
  const [locationLabel, setLocationLabel] = useState<string>(SAMPLE_PHOTOS[0].locationName);
  const [timestamp, setTimestamp] = useState<string>(new Date().toISOString());

  // Camera stream state
  const videoRef = useRef<HTMLVideoElement>(null);
  const [cameraActive, setCameraActive] = useState<boolean>(false);
  const [cameraError, setCameraError] = useState<string | null>(null);

  // Description & Voice State
  const [description, setDescription] = useState<string>(
    'Large hazardous pothole near 2nd Avenue junction in Adyar, cars and bikes are swerving dangerously.'
  );
  const [isRecording, setIsRecording] = useState<boolean>(false);
  const [voiceLang, setVoiceLang] = useState<string>('ta-IN');
  const [descriptionSource, setDescriptionSource] = useState<'typed' | 'voice_transcript'>('typed');

  // AI Categorization State
  const [aiSuggestedCategory, setAiSuggestedCategory] = useState<IssueCategory>('pothole');
  const [aiConfidence, setAiConfidence] = useState<number>(0.95);
  const [aiReasoning, setAiReasoning] = useState<string>(
    'Multimodal vision analysis identified deep asphalt depression in active traffic lane.'
  );
  const [selectedCategory, setSelectedCategory] = useState<IssueCategory>('pothole');
  const [isAiLoading, setIsAiLoading] = useState<boolean>(false);

  // Submission / Duplicate State
  const [submitting, setSubmitting] = useState<boolean>(false);
  const [createdComplaintId, setCreatedComplaintId] = useState<number | null>(null);
  const [referenceId, setReferenceId] = useState<string>('');
  const [duplicateCandidate, setDuplicateCandidate] = useState<DuplicateCandidate | null>(null);
  const [submissionResult, setSubmissionResult] = useState<any>(null);

  // Start in-app webcam
  const startCamera = async () => {
    try {
      setCameraError(null);
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'environment', width: { ideal: 1280 }, height: { ideal: 720 } },
        audio: false,
      });
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        videoRef.current.play();
        setCameraActive(true);
      }
    } catch (err: any) {
      console.warn('Camera access error:', err);
      setCameraError('In-app camera not accessible on this device. Please select a preset sample photo below.');
      setCameraActive(false);
    }
  };

  const stopCamera = () => {
    if (videoRef.current && videoRef.current.srcObject) {
      const stream = videoRef.current.srcObject as MediaStream;
      stream.getTracks().forEach((track) => track.stop());
      videoRef.current.srcObject = null;
    }
    setCameraActive(false);
  };

  const captureFrame = () => {
    if (videoRef.current) {
      const canvas = document.createElement('canvas');
      canvas.width = videoRef.current.videoWidth || 640;
      canvas.height = videoRef.current.videoHeight || 480;
      const ctx = canvas.getContext('2d');
      if (ctx) {
        ctx.drawImage(videoRef.current, 0, 0, canvas.width, canvas.height);
        const dataUrl = canvas.toDataURL('image/jpeg', 0.85);
        setCapturedPhotoUrl(dataUrl);
        setTimestamp(new Date().toISOString());
        stopCamera();
      }
    }
  };

  useEffect(() => {
    return () => {
      stopCamera();
    };
  }, []);

  // Voice recording & Sarvam AI transcription
  const handleVoiceTranscription = async (lang: string) => {
    setIsRecording(true);
    setVoiceLang(lang);

    try {
      const res = await fetch('/api/v1/ai/voice-transcribe', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ languageHint: lang, sampleIndex: 0 }),
      });
      const data = await res.json();
      if (data?.data) {
        setDescription(data.data.transcript);
        setDescriptionSource('voice_transcript');
      }
    } catch (err) {
      console.warn('Voice transcription fallback:', err);
    } finally {
      setIsRecording(false);
    }
  };

  // Run AI Categorization when moving from Step 2 to Step 3
  const handleRunAiCategorization = async () => {
    setIsAiLoading(true);
    setStep(3);

    try {
      const res = await fetch('/api/v1/ai/categorize', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          descriptionText: description,
          photoBase64: capturedPhotoUrl.startsWith('data:') ? capturedPhotoUrl : undefined,
        }),
      });
      const data = await res.json();
      if (data?.data) {
        setAiSuggestedCategory(data.data.category);
        setAiConfidence(data.data.confidence);
        setAiReasoning(data.data.reasoning);
        setSelectedCategory(data.data.category);
      }
    } catch (e) {
      console.warn('AI categorization request failed, using local fallback:', e);
    } finally {
      setIsAiLoading(false);
    }
  };

  // Submit Complaint
  const handleSubmit = async (duplicateIssueId?: number) => {
    setSubmitting(true);

    if (isOffline) {
      // Queue offline
      addOfflineReport({
        descriptionText: description,
        descriptionSource,
        voiceLanguageCode: voiceLang,
        photoUrl: capturedPhotoUrl,
        deviceGpsLat: gpsCoords.lat,
        deviceGpsLng: gpsCoords.lng,
        capturedAt: timestamp,
        finalCategory: selectedCategory,
      });
      setReferenceId(`OFFLINE-${Date.now().toString().slice(-4)}`);
      setStep(5);
      setSubmitting(false);
      return;
    }

    try {
      const res = await fetch('/api/v1/complaints', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-demo-user-id': String(currentUser.id),
        },
        body: JSON.stringify({
          descriptionText: description,
          descriptionSource,
          voiceLanguageCode: voiceLang,
          photoUrl: capturedPhotoUrl.startsWith('http') ? capturedPhotoUrl : undefined,
          photoBase64: capturedPhotoUrl.startsWith('data:') ? capturedPhotoUrl : undefined,
          deviceGpsLat: gpsCoords.lat,
          deviceGpsLng: gpsCoords.lng,
          photoExifLat: gpsCoords.lat,
          photoExifLng: gpsCoords.lng,
          gpsIsApproximate: false,
          capturedAt: timestamp,
          overrideCategory: selectedCategory,
          duplicateIssueId,
        }),
      });

      const json = await res.json();
      if (json?.data) {
        setCreatedComplaintId(json.data.complaintId);
        setReferenceId(json.data.referenceId);
        setSubmissionResult(json.data);

        // Check if duplicate candidate was found and we haven't already confirmed
        if (json.data.duplicateCandidate && !duplicateIssueId && step !== 4) {
          setDuplicateCandidate(json.data.duplicateCandidate);
          setStep(4); // Show Duplicate Interstitial
        } else {
          setStep(5); // Show Confirmation
          triggerRefresh();
        }
      }
    } catch (err: any) {
      alert('Submission failed: ' + err.message);
    } finally {
      setSubmitting(false);
    }
  };

  // Handle Duplicate Decision
  const handleDuplicateDecision = async (isSame: boolean) => {
    if (!createdComplaintId || !duplicateCandidate) {
      setStep(5);
      return;
    }

    try {
      setSubmitting(true);
      await fetch(`/api/v1/complaints/${createdComplaintId}/duplicate-decision`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          decision: isSame ? 'same_issue' : 'different_issue',
          targetIssueId: isSame ? duplicateCandidate.issueId : undefined,
        }),
      });
      triggerRefresh();
      setStep(5);
    } catch (err: any) {
      alert('Error updating duplicate decision: ' + err.message);
      setStep(5);
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="max-w-2xl mx-auto px-4 py-8">
      {/* Step Progress Header */}
      <div className="mb-8">
        <div className="flex items-center justify-between text-xs font-bold text-slate-500 mb-2">
          <span>STEP {step} OF 5</span>
          <span>
            {step === 1 && '1. Camera Evidence Capture'}
            {step === 2 && '2. Voice & Description'}
            {step === 3 && '3. AI Category Review'}
            {step === 4 && '4. Duplicate Verification'}
            {step === 5 && '5. Registration Receipt'}
          </span>
        </div>
        <div className="w-full h-2 bg-slate-200 rounded-full overflow-hidden flex">
          <div
            className="bg-blue-600 h-full transition-all duration-300 rounded-full"
            style={{ width: `${(step / 5) * 100}%` }}
          />
        </div>
      </div>

      {/* ---------------------------------------------------- */}
      {/* STEP 1: CAMERA EVIDENCE CAPTURE (F-01, C-2) */}
      {/* ---------------------------------------------------- */}
      {step === 1 && (
        <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm space-y-6">
          <div className="space-y-1">
            <h2 className="text-xl font-extrabold text-slate-900 flex items-center gap-2">
              <Camera className="w-5 h-5 text-blue-600" />
              <span>Capture Fresh In-App Photo</span>
            </h2>
            <p className="text-xs text-slate-500">
              Camera-first evidence attaches locked GPS coordinates and timestamp to eliminate fraudulent submissions.
            </p>
          </div>

          {/* Camera Viewfinder / Preview */}
          <div className="relative rounded-xl overflow-hidden bg-slate-950 aspect-4/3 flex items-center justify-center border border-slate-800">
            {cameraActive ? (
              <video ref={videoRef} autoPlay playsInline className="w-full h-full object-cover" />
            ) : (
              <img
                src={capturedPhotoUrl}
                alt="Captured Evidence"
                className="w-full h-full object-cover"
              />
            )}

            {/* Geotag & Timestamp Chip Overlay */}
            <div className="absolute top-3 left-3 bg-slate-900/80 backdrop-blur-md text-white px-3 py-1.5 rounded-lg text-xs space-y-0.5 border border-white/20 shadow-md">
              <div className="flex items-center gap-1.5 font-bold text-emerald-400">
                <MapPin className="w-3.5 h-3.5" />
                <span>GPS Locked: {gpsCoords.lat.toFixed(4)}° N, {gpsCoords.lng.toFixed(4)}° E</span>
              </div>
              <div className="flex items-center gap-1.5 text-slate-300 text-[11px]">
                <Clock className="w-3 h-3" />
                <span>{new Date(timestamp).toLocaleTimeString()} · {locationLabel}</span>
              </div>
            </div>

            {/* In-Viewfinder Capture Button */}
            {cameraActive && (
              <div className="absolute bottom-4 inset-x-0 flex justify-center">
                <button
                  onClick={captureFrame}
                  className="w-16 h-16 rounded-full bg-white border-4 border-blue-600 shadow-xl flex items-center justify-center hover:scale-105 active:scale-95 transition"
                >
                  <div className="w-12 h-12 rounded-full bg-rose-600" />
                </button>
              </div>
            )}
          </div>

          {/* Camera controls & preset samples */}
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <button
                type="button"
                onClick={cameraActive ? stopCamera : startCamera}
                className="inline-flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold border border-slate-300 hover:bg-slate-50 transition"
              >
                <Camera className="w-4 h-4 text-blue-600" />
                <span>{cameraActive ? 'Close Live Camera' : 'Open Device Camera'}</span>
              </button>

              <span className="text-xs text-slate-400">or pick demo scenario photo:</span>
            </div>

            {cameraError && (
              <p className="text-xs text-amber-700 bg-amber-50 p-2.5 rounded-lg border border-amber-200">
                {cameraError}
              </p>
            )}

            {/* Quick Demo Photo Presets */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
              {SAMPLE_PHOTOS.map((sample) => (
                <button
                  key={sample.id}
                  type="button"
                  onClick={() => {
                    stopCamera();
                    setCapturedPhotoUrl(sample.url);
                    setGpsCoords({ lat: sample.lat, lng: sample.lng });
                    setLocationLabel(sample.locationName);
                    setTimestamp(new Date().toISOString());
                  }}
                  className={`p-2 rounded-xl border text-left transition flex flex-col gap-1.5 ${
                    capturedPhotoUrl === sample.url
                      ? 'border-blue-600 bg-blue-50/50 ring-2 ring-blue-500/20'
                      : 'border-slate-200 hover:border-slate-300 bg-white'
                  }`}
                >
                  <img
                    src={sample.url}
                    alt={sample.label}
                    className="w-full h-16 object-cover rounded-lg"
                  />
                  <span className="text-[11px] font-bold text-slate-800 line-clamp-1 leading-tight">
                    {sample.label}
                  </span>
                  <span className="text-[10px] text-slate-500 line-clamp-1">{sample.locationName}</span>
                </button>
              ))}
            </div>
          </div>

          <div className="pt-4 border-t border-slate-100 flex justify-end">
            <button
              onClick={() => setStep(2)}
              className="inline-flex items-center gap-2 bg-blue-600 hover:bg-blue-500 text-white px-6 py-2.5 rounded-xl text-xs font-bold shadow-sm transition"
            >
              <span>Next: Voice & Description</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* ---------------------------------------------------- */}
      {/* STEP 2: VOICE & DESCRIPTION (F-01, F-03, C-3) */}
      {/* ---------------------------------------------------- */}
      {step === 2 && (
        <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm space-y-6">
          <div className="space-y-1">
            <h2 className="text-xl font-extrabold text-slate-900 flex items-center gap-2">
              <Mic className="w-5 h-5 text-blue-600" />
              <span>Describe the Issue</span>
            </h2>
            <p className="text-xs text-slate-500">
              Speak in Tamil, Hindi, or English. Audio is transcribed via Sarvam AI and remains fully editable.
            </p>
          </div>

          {/* Voice Input Buttons (F-03 Sarvam Demo) */}
          <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-700 flex items-center gap-1.5">
                <Volume2 className="w-4 h-4 text-blue-600" />
                <span>Multi-Language Voice Input</span>
              </span>
              {isRecording && (
                <span className="flex items-center gap-1.5 text-xs font-bold text-rose-600 animate-pulse">
                  <span className="w-2 h-2 rounded-full bg-rose-600" />
                  Transcribing with Sarvam AI...
                </span>
              )}
            </div>

            <div className="grid grid-cols-3 gap-2">
              <button
                type="button"
                onClick={() => handleVoiceTranscription('ta-IN')}
                disabled={isRecording}
                className="flex items-center justify-center gap-2 bg-white hover:bg-blue-50 border border-slate-200 hover:border-blue-300 py-2 px-3 rounded-lg text-xs font-bold text-slate-800 transition"
              >
                <Mic className="w-3.5 h-3.5 text-blue-600" />
                <span>தமிழ் (Tamil)</span>
              </button>

              <button
                type="button"
                onClick={() => handleVoiceTranscription('hi-IN')}
                disabled={isRecording}
                className="flex items-center justify-center gap-2 bg-white hover:bg-blue-50 border border-slate-200 hover:border-blue-300 py-2 px-3 rounded-lg text-xs font-bold text-slate-800 transition"
              >
                <Mic className="w-3.5 h-3.5 text-purple-600" />
                <span>हिंदी (Hindi)</span>
              </button>

              <button
                type="button"
                onClick={() => handleVoiceTranscription('en-IN')}
                disabled={isRecording}
                className="flex items-center justify-center gap-2 bg-white hover:bg-blue-50 border border-slate-200 hover:border-blue-300 py-2 px-3 rounded-lg text-xs font-bold text-slate-800 transition"
              >
                <Mic className="w-3.5 h-3.5 text-emerald-600" />
                <span>English</span>
              </button>
            </div>
          </div>

          {/* Description Textarea */}
          <div className="space-y-2">
            <label className="text-xs font-bold text-slate-700 block">
              Issue Details (Editable Transcript)
            </label>
            <textarea
              rows={4}
              value={description}
              onChange={(e) => {
                setDescription(e.target.value);
                setDescriptionSource('typed');
              }}
              placeholder="e.g. Deep pothole near the bus stop, traffic swerving..."
              className="w-full text-sm p-3.5 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 leading-relaxed bg-white"
            />
            <div className="flex items-center justify-between text-[11px] text-slate-400">
              <span>Source: {descriptionSource === 'voice_transcript' ? `Voice (${voiceLang})` : 'Manual typing'}</span>
              <span>{description.length} characters</span>
            </div>
          </div>

          <div className="pt-4 border-t border-slate-100 flex justify-between">
            <button
              onClick={() => setStep(1)}
              className="inline-flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-semibold text-slate-600 hover:bg-slate-100 transition"
            >
              <ArrowLeft className="w-4 h-4" />
              <span>Back</span>
            </button>

            <button
              onClick={handleRunAiCategorization}
              className="inline-flex items-center gap-2 bg-blue-600 hover:bg-blue-500 text-white px-6 py-2.5 rounded-xl text-xs font-bold shadow-sm transition"
            >
              <Sparkles className="w-4 h-4 text-amber-300" />
              <span>Analyze with AI</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* ---------------------------------------------------- */}
      {/* STEP 3: AI CATEGORY REVIEW (FR-05, F-04, C-4) */}
      {/* ---------------------------------------------------- */}
      {step === 3 && (
        <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm space-y-6">
          <div className="space-y-1">
            <h2 className="text-xl font-extrabold text-slate-900 flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-amber-500" />
              <span>AI Category Suggestion</span>
            </h2>
            <p className="text-xs text-slate-500">
              AI proposes a category, but you have the final say (Principle 5: AI is not final-say).
            </p>
          </div>

          {/* Gemini Analysis Card */}
          <div className="bg-gradient-to-r from-blue-50 to-indigo-50 border border-blue-200 rounded-xl p-4.5 space-y-3">
            <div className="flex items-center justify-between">
              <span className="inline-flex items-center gap-1.5 text-xs font-bold text-blue-900 bg-blue-100 px-2.5 py-1 rounded-full">
                <Sparkles className="w-3.5 h-3.5 text-amber-600" />
                Gemini Vision Suggestion
              </span>
              <span className="text-xs font-extrabold text-emerald-700 bg-emerald-100 px-2.5 py-1 rounded-full">
                {Math.round(aiConfidence * 100)}% Confidence
              </span>
            </div>

            <div className="flex items-center gap-3 bg-white p-3.5 rounded-xl border border-blue-100 shadow-xs">
              <span className="text-3xl">
                {CATEGORIES.find((c) => c.id === aiSuggestedCategory)?.icon || '📍'}
              </span>
              <div>
                <h4 className="text-sm font-extrabold text-slate-900 capitalize">
                  {aiSuggestedCategory.replace('_', ' ')}
                </h4>
                <p className="text-xs text-slate-500 mt-0.5">{aiReasoning}</p>
              </div>
            </div>
          </div>

          {/* 8-Category Human Selection Grid */}
          <div className="space-y-3">
            <label className="text-xs font-bold text-slate-700 block">
              Confirm or Change Category:
            </label>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
              {CATEGORIES.map((cat) => (
                <button
                  key={cat.id}
                  type="button"
                  onClick={() => setSelectedCategory(cat.id)}
                  className={`p-3 rounded-xl border text-left transition flex flex-col gap-1 ${
                    selectedCategory === cat.id
                      ? 'border-blue-600 bg-blue-50/60 ring-2 ring-blue-500/20 font-bold'
                      : 'border-slate-200 hover:border-slate-300 bg-white'
                  }`}
                >
                  <span className="text-xl">{cat.icon}</span>
                  <span className="text-xs text-slate-900 capitalize leading-tight">
                    {cat.label}
                  </span>
                  <span className="text-[10px] text-slate-400 leading-tight line-clamp-1">
                    {cat.dept}
                  </span>
                </button>
              ))}
            </div>
          </div>

          <div className="pt-4 border-t border-slate-100 flex justify-between">
            <button
              onClick={() => setStep(2)}
              className="inline-flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-semibold text-slate-600 hover:bg-slate-100 transition"
            >
              <ArrowLeft className="w-4 h-4" />
              <span>Back</span>
            </button>

            <button
              onClick={() => handleSubmit()}
              disabled={submitting}
              className="inline-flex items-center gap-2 bg-blue-600 hover:bg-blue-500 text-white px-6 py-2.5 rounded-xl text-xs font-bold shadow-sm transition disabled:opacity-50"
            >
              {submitting ? (
                <span>Registering & Geo-Routing...</span>
              ) : (
                <>
                  <CheckCircle2 className="w-4 h-4" />
                  <span>Submit Complaint</span>
                </>
              )}
            </button>
          </div>
        </div>
      )}

      {/* ---------------------------------------------------- */}
      {/* STEP 4: DUPLICATE VERIFICATION INTERSTITIAL (F-06, C-5) */}
      {/* ---------------------------------------------------- */}
      {step === 4 && duplicateCandidate && (
        <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm space-y-6">
          <div className="space-y-1">
            <div className="inline-flex items-center gap-1.5 bg-amber-100 text-amber-900 px-3 py-1 rounded-full text-xs font-bold">
              <AlertTriangle className="w-3.5 h-3.5 text-amber-600" />
              <span>Nearby Similar Issue Detected (Within 75m)</span>
            </div>
            <h2 className="text-xl font-extrabold text-slate-900 mt-2">
              Is this the same issue?
            </h2>
            <p className="text-xs text-slate-600 leading-relaxed">
              We found an existing open {duplicateCandidate.category} report {duplicateCandidate.distanceM} meters away
              with {duplicateCandidate.existingComplaintCount} prior report(s).
            </p>
          </div>

          {/* Matched Issue Card */}
          <div className="bg-slate-50 border border-slate-200 rounded-xl p-4.5 space-y-3">
            <div className="flex items-center justify-between text-xs">
              <span className="font-bold text-slate-700">Existing Issue #{duplicateCandidate.issueId}</span>
              <span className="bg-blue-100 text-blue-800 px-2 py-0.5 rounded font-semibold text-[11px]">
                {duplicateCandidate.existingComplaintCount} Community Report(s)
              </span>
            </div>

            {duplicateCandidate.photoUrl && (
              <img
                src={duplicateCandidate.photoUrl}
                alt="Existing report"
                className="w-full h-36 object-cover rounded-lg border border-slate-200"
              />
            )}

            <div className="text-xs text-slate-600 space-y-1">
              <p>
                <strong>Category:</strong> {duplicateCandidate.category.toUpperCase()}
              </p>
              <p>
                <strong>Distance from your GPS:</strong> {duplicateCandidate.distanceM} meters
              </p>
              <p className="text-[11px] text-slate-500 italic">
                * Note: Linking your report confirms community corroboration and increases the priority score for faster municipal action.
              </p>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3 pt-2">
            <button
              onClick={() => handleDuplicateDecision(true)}
              disabled={submitting}
              className="w-full bg-blue-600 hover:bg-blue-500 text-white font-bold py-3 rounded-xl text-xs shadow-sm transition flex items-center justify-center gap-2"
            >
              <CheckCircle2 className="w-4 h-4" />
              <span>Yes, Same Issue (Merge & Corroborate)</span>
            </button>

            <button
              onClick={() => handleDuplicateDecision(false)}
              disabled={submitting}
              className="w-full bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold py-3 rounded-xl text-xs transition"
            >
              <span>No, This is Different</span>
            </button>
          </div>
        </div>
      )}

      {/* ---------------------------------------------------- */}
      {/* STEP 5: REGISTRATION RECEIPT (F-01, F-02, C-6) */}
      {/* ---------------------------------------------------- */}
      {step === 5 && (
        <div className="bg-white rounded-2xl border border-slate-200 p-6 sm:p-8 shadow-sm space-y-6 text-center">
          <div className="w-16 h-16 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto shadow-inner">
            <CheckCircle2 className="w-9 h-9" />
          </div>

          <div className="space-y-1">
            <h2 className="text-2xl font-extrabold text-slate-900">
              {isOffline ? 'Report Queued Offline' : 'Complaint Successfully Registered!'}
            </h2>
            <p className="text-xs text-slate-500">
              {isOffline
                ? 'Your evidence is safely stored on device and will sync when you are back online.'
                : 'Your report has been geotagged, risk-scored, and routed to the municipal ward department.'}
            </p>
          </div>

          {/* Reference Receipt Card */}
          <div className="bg-slate-50 border border-slate-200 rounded-xl p-5 text-left space-y-3 font-mono text-xs max-w-md mx-auto">
            <div className="flex justify-between border-b border-slate-200 pb-2 font-sans font-bold text-slate-800">
              <span>Receipt Details</span>
              <span className="text-blue-600 font-bold">STATUS: SUBMITTED</span>
            </div>

            <div className="flex justify-between">
              <span className="text-slate-500">Reference ID:</span>
              <span className="font-bold text-slate-900">{referenceId}</span>
            </div>

            <div className="flex justify-between">
              <span className="text-slate-500">Reporter:</span>
              <span className="text-slate-900">{currentUser.displayName}</span>
            </div>

            <div className="flex justify-between">
              <span className="text-slate-500">Category:</span>
              <span className="text-slate-900 capitalize">{selectedCategory}</span>
            </div>

            <div className="flex justify-between">
              <span className="text-slate-500">Assigned Zone:</span>
              <span className="text-slate-900">Zone 13 - Adyar (Ward 175)</span>
            </div>

            <div className="flex justify-between">
              <span className="text-slate-500">Target Department:</span>
              <span className="text-slate-900">
                {CATEGORIES.find((c) => c.id === selectedCategory)?.dept || 'Roads & Infra'}
              </span>
            </div>
          </div>

          <div className="pt-4 flex flex-col sm:flex-row items-center justify-center gap-3">
            <button
              onClick={onFinish}
              className="w-full sm:w-auto inline-flex items-center justify-center gap-2 bg-blue-600 hover:bg-blue-500 text-white px-6 py-3 rounded-xl text-xs font-bold shadow-sm transition"
            >
              <span>View in "My Reports"</span>
              <ArrowRight className="w-4 h-4" />
            </button>

            <button
              onClick={() => {
                setStep(1);
                setDescription('Pothole on 2nd Ave near bus stop.');
              }}
              className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-5 py-3 rounded-xl text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 transition"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Report Another Issue</span>
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
